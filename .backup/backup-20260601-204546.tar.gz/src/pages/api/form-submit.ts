import type { APIRoute } from "astro";

// 获取中国本地时间字符串（YYYY-MM-DD HH:mm:ss）
function getChinaTimeString() {
  const now = new Date();
  const chinaTime = new Date(now.getTime() + 8 * 60 * 60 * 1000);
  return chinaTime.toISOString().slice(0, 19).replace("T", " ");
}

// 初始化SQLite数据库（使用动态导入避免Vite SSR编译问题）
export async function initDB() {
  const sqlite3 = await import("sqlite3");
  const { open } = await import("sqlite");

  const db = await open({
    filename: "./safety-form.db",
    driver: sqlite3.default.Database,
  });

  // 创建表（如果不存在）
  await db.exec(`
    CREATE TABLE IF NOT EXISTS form_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_name TEXT NOT NULL,
      check_date TEXT NOT NULL,
      logistics_company TEXT NOT NULL,
      operator TEXT NOT NULL,
      type TEXT NOT NULL,
      location TEXT NOT NULL,
      description TEXT NOT NULL,
      files TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- 考试项目表
    CREATE TABLE IF NOT EXISTS exam_projects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT,
      pass_score INTEGER NOT NULL DEFAULT 80,
      total_score INTEGER NOT NULL DEFAULT 100,
      duration INTEGER NOT NULL DEFAULT 60,
      is_active BOOLEAN DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- 考试题目表
    CREATE TABLE IF NOT EXISTS exam_questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER NOT NULL,
      type TEXT NOT NULL DEFAULT 'single',
      question TEXT NOT NULL,
      options TEXT,
      answer TEXT NOT NULL,
      score INTEGER NOT NULL DEFAULT 4,
      sort_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (project_id) REFERENCES exam_projects(id) ON DELETE CASCADE
    );

    -- 考试记录表
    CREATE TABLE IF NOT EXISTS exam_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id INTEGER NOT NULL,
      company TEXT NOT NULL,
      name TEXT NOT NULL,
      position TEXT,
      score INTEGER NOT NULL,
      total_score INTEGER NOT NULL,
      duration INTEGER NOT NULL,
      passed BOOLEAN NOT NULL,
      answers TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (project_id) REFERENCES exam_projects(id)
    );

    -- 知识库文章表
    CREATE TABLE IF NOT EXISTS knowledge_articles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      content TEXT NOT NULL,
      author TEXT DEFAULT '系统',
      views INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    -- 事故案例表
    CREATE TABLE IF NOT EXISTS accident_cases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      severity TEXT NOT NULL,
      cause TEXT,
      prevention TEXT,
      location TEXT,
      date TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // 初始化默认管理员账号（用户名：admin，密码：admin123）
  const existingAdmin = await db.get('SELECT * FROM users WHERE username = ?', 'admin');
  if (!existingAdmin) {
    const bcrypt = await import("bcryptjs");
    const hashedPassword = await bcrypt.default.hash('admin123', 10);
    await db.run(
      'INSERT INTO users (username, password, role) VALUES (?, ?, ?)',
      ['admin', hashedPassword, 'admin']
    );
  }

  return db;
}

export const POST: APIRoute = async ({ request }) => {
  try {
    const formData = await request.json();
    const {
      project_name,
      check_date,
      logistics_company,
      operator,
      type,
      location,
      description,
      files,
    } = formData;

    // 简单校验
    if (!project_name || !check_date || !logistics_company || !operator || !type || !location || !description || !files) {
      return new Response(
        JSON.stringify({ success: false, message: "请填写完整信息" }),
        { status: 400 }
      );
    }

    const db = await initDB();

    // 插入数据
    const result = await db.run(
      `INSERT INTO form_records (
        project_name, check_date, logistics_company, operator, type, location, description, files, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        project_name,
        check_date,
        logistics_company,
        operator,
        type,
        location,
        description,
        JSON.stringify(files),
        getChinaTimeString(),
      ]
    );

    await db.close();

    return new Response(
      JSON.stringify({
        success: true,
        message: "提交成功",
        data: {
          id: result.lastID,
        },
      }),
      { status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        message: "提交失败",
        error: error instanceof Error ? error.message : "未知错误",
      }),
      { status: 500 }
    );
  }
};