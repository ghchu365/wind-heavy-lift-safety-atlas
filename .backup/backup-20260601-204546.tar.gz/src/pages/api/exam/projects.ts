import type { APIRoute } from "astro";
import { initDB } from "../form-submit";

// 获取中国本地时间字符串（YYYY-MM-DD HH:mm:ss）
function getChinaTimeString() {
  const now = new Date();
  const chinaTime = new Date(now.getTime() + 8 * 60 * 60 * 1000);
  return chinaTime.toISOString().slice(0, 19).replace("T", " ");
}

export const GET: APIRoute = async ({ request, url }) => {
  try {
    const db = await initDB();
    const activeOnly = url.searchParams.get('active') === 'true';

    let query = 'SELECT * FROM exam_projects';
    const params: any[] = [];

    if (activeOnly) {
      query += ' WHERE is_active = 1';
    }

    query += ' ORDER BY created_at DESC';

    const projects = await db.all(query, params);
    await db.close();

    return new Response(
      JSON.stringify({
        success: true,
        data: projects,
      }),
      { status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        message: "获取失败",
        error: error instanceof Error ? error.message : "未知错误",
      }),
      { status: 500 }
    );
  }
};

export const POST: APIRoute = async ({ request }) => {
  try {
    const data = await request.json();
    const { name, description, pass_score, total_score, duration, is_active } = data;

    if (!name) {
      return new Response(
        JSON.stringify({ success: false, message: "请输入考试项目名称" }),
        { status: 400 }
      );
    }

    const db = await initDB();
    const result = await db.run(
      `INSERT INTO exam_projects (name, description, pass_score, total_score, duration, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        name,
        description || '',
        pass_score || 80,
        total_score || 100,
        duration || 60,
        is_active !== undefined ? is_active : 1,
        getChinaTimeString(),
        getChinaTimeString(),
      ]
    );

    await db.close();

    return new Response(
      JSON.stringify({
        success: true,
        message: "创建成功",
        data: { id: result.lastID },
      }),
      { status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        message: "创建失败",
        error: error instanceof Error ? error.message : "未知错误",
      }),
      { status: 500 }
    );
  }
};