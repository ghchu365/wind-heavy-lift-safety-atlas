import type { APIRoute } from "astro";
import { initDB } from "../form-submit";

// 获取中国本地时间字符串（YYYY-MM-DD HH:mm:ss）
function getChinaTimeString() {
  const now = new Date();
  const chinaTime = new Date(now.getTime() + 8 * 60 * 60 * 1000);
  return chinaTime.toISOString().slice(0, 19).replace("T", " ");
}

export const GET: APIRoute = async ({ url }) => {
  try {
    const projectId = url.searchParams.get('project_id');
    if (!projectId) {
      return new Response(
        JSON.stringify({ success: false, message: "请提供考试项目ID" }),
        { status: 400 }
      );
    }

    const db = await initDB();
    const questions = await db.all(
      'SELECT * FROM exam_questions WHERE project_id = ? ORDER BY sort_order, id',
      projectId
    );
    await db.close();

    return new Response(
      JSON.stringify({
        success: true,
        data: questions,
      }),
      { status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        message: "获取失败",
        error: error instanceof Error ? error.message : "未知错误",
      }),
      { status: 500 }
    );
  }
};

export const POST: APIRoute = async ({ request }) => {
  try {
    const data = await request.json();
    const { project_id, type, question, options, answer, score, sort_order } = data;

    if (!project_id || !question || answer === undefined || answer === null) {
      return new Response(
        JSON.stringify({ success: false, message: "请填写完整信息" }),
        { status: 400 }
      );
    }

    const db = await initDB();
    const result = await db.run(
      `INSERT INTO exam_questions (project_id, type, question, options, answer, score, sort_order, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        project_id,
        type || 'single',
        question,
        JSON.stringify(options || []),
        JSON.stringify(answer),
        score || 4,
        sort_order || 0,
        getChinaTimeString(),
      ]
    );

    await db.close();

    return new Response(
      JSON.stringify({
        success: true,
        message: "创建成功",
        data: { id: result.lastID },
      }),
      { status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        message: "创建失败",
        error: error instanceof Error ? error.message : "未知错误",
      }),
      { status: 500 }
    );
  }
};

export const PUT: APIRoute = async ({ request }) => {
  try {
    const data = await request.json();
    const { id, type, question, options, answer, score, sort_order } = data;

    if (!id || !question || answer === undefined || answer === null) {
      return new Response(
        JSON.stringify({ success: false, message: "请填写完整信息" }),
        { status: 400 }
      );
    }

    const db = await initDB();
    await db.run(
      `UPDATE exam_questions SET type = ?, question = ?, options = ?, answer = ?, score = ?, sort_order = ? WHERE id = ?`,
      [
        type || 'single',
        question,
        JSON.stringify(options || []),
        JSON.stringify(answer),
        score || 4,
        sort_order || 0,
        id,
      ]
    );

    await db.close();

    return new Response(
      JSON.stringify({
        success: true,
        message: "更新成功",
      }),
      { status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        message: "更新失败",
        error: error instanceof Error ? error.message : "未知错误",
      }),
      { status: 500 }
    );
  }
};

export const DELETE: APIRoute = async ({ request }) => {
  try {
    const data = await request.json();
    const { id } = data;

    if (!id) {
      return new Response(
        JSON.stringify({ success: false, message: "请提供题目ID" }),
        { status: 400 }
      );
    }

    const db = await initDB();
    await db.run('DELETE FROM exam_questions WHERE id = ?', id);
    await db.close();

    return new Response(
      JSON.stringify({
        success: true,
        message: "删除成功",
      }),
      { status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        message: "删除失败",
        error: error instanceof Error ? error.message : "未知错误",
      }),
      { status: 500 }
    );
  }
};