import type { APIRoute } from "astro";
import { initDB } from "../form-submit";

export const GET: APIRoute = async ({ url }) => {
  try {
    const db = await initDB();
    const category = url.searchParams.get('category');

    let query = 'SELECT * FROM knowledge_articles';
    const params: any[] = [];

    if (category) {
      query += ' WHERE category = ?';
      params.push(category);
    }

    query += ' ORDER BY created_at DESC';

    const articles = await db.all(query, params);
    await db.close();

    return new Response(
      JSON.stringify({
        success: true,
        data: articles,
      }),
      { status: 200 }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({
        success: false,
        message: "获取失败",
        error: error instanceof Error ? error.message : "未知错误",
      }),
      { status: 500 }
    );
  }
};
