import { defineConfig } from 'astro/config';
import tailwind from '@astrojs/tailwind';
import react from '@astrojs/react';

export default defineConfig({
  output: 'server',
  integrations: [tailwind(), react()],
  site: 'https://example.com',
  vite: {
    ssr: {
      external: ['sqlite3', 'bcryptjs', 'jsonwebtoken', 'sqlite']
    }
  }
});
